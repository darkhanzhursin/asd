package bank.proxy;

public class Logger {
  public void log(String message) {
	  System.out.println(message);
  }
}
